import numpy as np
import sys

def extract_stego_pixels(original_txt, stego_txt, k):
    # Đọc dữ liệu từ file input.txt và output.txt
    with open(original_txt, "r", encoding="utf-8") as file:
        original_pixels = np.array(list(map(int, file.read().split())))
    with open(stego_txt, "r", encoding="utf-8") as file:
        stego_pixels = np.array(list(map(int, file.read().split())))
    
    # Tạo mặt nạ cho k bit thấp nhất
    mask = 2**k - 1
    
    # Trích xuất LSB từ ảnh gốc và ảnh stego để so sánh
    original_lsb = original_pixels & mask
    stego_lsb = stego_pixels & mask
    
    # Tìm các pixel có LSB khác nhau
    diff_lsb = original_lsb != stego_lsb
    num_diff = np.sum(diff_lsb)
    print(f"So diem anh co LSB nhau: {num_diff}")
    
    # Trích xuất chuỗi nhị phân từ ảnh stego để tìm dấu kết thúc
    binary_message = ""
    for pixel in stego_pixels:
        lsb_bits = pixel & mask
        binary_message += format(lsb_bits, f'0{k}b')
    
    # Tìm vị trí dấu kết thúc '11111111'
    end_marker = '11111111'
    if end_marker in binary_message:
        end_index = binary_message.index(end_marker) // k  # Chia cho k để lấy số pixel
        # print("Đã tìm thấy dấu kết thúc '11111111'!")
    else:
        end_index = len(stego_pixels)  # Nếu không tìm thấy, lấy hết
        # print("Không tìm thấy dấu kết thúc, lấy toàn bộ pixel.")
    
    # Lấy các pixel từ đầu đến dấu kết thúc
    message_pixels = stego_pixels[:end_index]  # +1 để bao gồm pixel cuối
    
    # Ghi các pixel vào file thongdiep.txt
    with open("thongdiep.txt", "w", encoding="utf-8") as file:
        file.write(" ".join(map(str, message_pixels)))
    print("Cac diem anh se duoc ghi vao file thongdiep.txt")
    
    return message_pixels

# Gọi hàm với hai file txt, ví dụ k=2
extracted_pixels = extract_stego_pixels(sys.argv[1], sys.argv[2], k=2)