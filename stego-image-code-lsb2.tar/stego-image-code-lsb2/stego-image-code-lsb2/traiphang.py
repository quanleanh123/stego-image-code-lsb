from PIL import Image
import numpy as np
import sys

def preprocess_images(original_path,text1, stego_path,text2):
    # Mở và chuyển ảnh gốc sang dạng xám
    original_img = Image.open(original_path).convert('L')
    # Mở và chuyển ảnh stego sang dạng xám
    stego_img = Image.open(stego_path).convert('L')
    
    # Chuyển ảnh sang mảng numpy và trải phẳng
    original_pixels = np.array(original_img).flatten()
    stego_pixels = np.array(stego_img).flatten()
    
    # Ghi mảng pixel của ảnh gốc vào file input.txt
    with open(text1, "w", encoding="utf-8") as file:
        file.write(" ".join(map(str, original_pixels)))
    print("Da trai phang anh goc")
    
    # Ghi mảng pixel của ảnh stego vào file output.txt
    with open(text2, "w", encoding="utf-8") as file:
        file.write(" ".join(map(str, stego_pixels)))
    print("Da trai phang anh giau tin")

# Gọi hàm với hai file ảnh đầu vào
preprocess_images(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4])