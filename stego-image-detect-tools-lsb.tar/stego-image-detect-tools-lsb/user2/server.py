import socket

s = socket.socket()
s.bind(('0.0.0.0', 2121))
s.listen(1)
print("Đang lắng nghe trên port 2121...")

conn, addr = s.accept()
print(f"Kết nối từ {addr}")
with open('./stego.png', 'wb') as f:
    while True:
        data = conn.recv(1024)
        if not data:
            break
        f.write(data)
print("Đã nhận file stego.png.")
conn.close()
s.close()
