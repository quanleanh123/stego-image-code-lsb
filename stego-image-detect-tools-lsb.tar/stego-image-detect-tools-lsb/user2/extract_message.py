from PIL import Image
import os

# Hàm giải mã Vigenère
def vigenere_decrypt(encrypted_message, key):
    if len(encrypted_message) != len(key):
        raise ValueError("Độ dài thông điệp và khóa phải bằng nhau")
    decrypted = ''
    for i in range(len(encrypted_message)):
        if not encrypted_message[i].isalpha() or not key[i].isalpha():
            raise ValueError("Thông điệp và khóa chỉ chứa chữ cái A-Z")
        c = ord(encrypted_message[i].upper()) - ord('A')
        k = ord(key[i].upper()) - ord('A')
        m = (c - k) % 26
        decrypted += chr(m + ord('A'))
    return decrypted

# Hàm chuyển đổi nhị phân thành chuỗi
def binary_to_text(binary):
    text = ''
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        if len(byte) == 8:
            text += chr(int(byte, 2))
    return text

# Hàm tách thông điệp (2 bit mỗi điểm ảnh)
def extract_message(image_path, key):
    img = Image.open(image_path)
    if img.mode != 'L':
        img = img.convert('L')
    pixels = img.load()
    width, height = img.size
    
    # Tách 2 bit từ mỗi điểm ảnh
    binary_message = ''
    for i in range(16):
        x = i % width
        y = i // width
        pixel = pixels[x, y]
        bit0 = pixel & 1  # Bit thấp nhất
        bit1 = (pixel >> 1) & 1  # Bit thứ hai
        binary_message += str(bit0) + str(bit1)
    
    # Chuyển nhị phân thành chuỗi (giả định 4 ký tự)
    encrypted_message = binary_to_text(binary_message[:32])  # Lấy 32 bit (4 ký tự)
    
    # Giải mã
    message = vigenere_decrypt(encrypted_message, key)
    return message

if __name__ == "__main__":
    stego_image = "stego.png"
    key_file = "key.bin"
    
    if not os.path.exists(stego_image):
        print(f"Không tìm thấy {stego_image}")
        exit(1)
    if not os.path.exists(key_file):
        print(f"Không tìm thấy {key_file}")
        exit(1)
    
    with open(key_file, 'r') as f:
        key = f.read().strip()
    
    try:
        message = extract_message(stego_image, key)
        print(f"User2: Thông điệp giải mã: {message}")
    except Exception as e:
        print(f"Lỗi: {e}")