import socket
import os

server_ip = "174.20.0.20"  # IP của User2
file_name = "steg.png"

if not os.path.exists(file_name):
    print(f"File '{file_name}' không tồn tại.")
    exit(1)

s = socket.socket()
try:
    s.connect((server_ip, 2121))
    print(f"Đang gửi file '{file_name}' đến {server_ip}...")
    with open(file_name, 'rb') as f:
        data = f.read()
        s.sendall(data)

    print("Hoàn tất gửi file!")
except Exception as e:
    print(f"Lỗi: {e}")
finally:
    s.close()
