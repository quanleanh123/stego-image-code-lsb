import os

# Hàm mã hóa Vigenère
def vigenere_encrypt(message, key):
    if len(message) != len(key):
        raise ValueError("Độ dài thông điệp và khóa phải bằng nhau")
    encrypted = ''
    for i in range(len(message)):
        if not message[i].isalpha() or not key[i].isalpha():
            raise ValueError("Thông điệp và khóa chỉ chứa chữ cái A-Z")
        m = ord(message[i].upper()) - ord('A')  # Chuyển ký tự thành số (0-25)
        k = ord(key[i].upper()) - ord('A')
        c = (m + k) % 26  # Mã hóa: (m + k) mod 26
        encrypted += chr(c + ord('A'))  # Chuyển số thành ký tự
    return encrypted

if __name__ == "__main__":
    message = "RTIT"
    key = "KEYS"  # Khóa 4 ký tự
    output_file = "encrypted_message.txt"
    
    try:
        encrypted_message = vigenere_encrypt(message, key)
        with open(output_file, 'w') as f:
            f.write(encrypted_message)
        print(f"User1: Đã mã hóa thông điệp '{message}' thành '{encrypted_message}' và lưu vào {output_file}")
    except Exception as e:
        print(f"Lỗi: {e}")
