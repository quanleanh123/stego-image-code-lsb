from PIL import Image
import os

def text_to_binary(text):
    binary = ''.join(format(ord(c), '08b') for c in text)
    return binary


def hide_message(image_path, message_file, output_path):

    with open(message_file, 'r') as f:
        encrypted_message = f.read()
    

    if len(encrypted_message) != 4:
        raise ValueError("Thông điệp phải có đúng 4 ký tự")
    

    binary_message = text_to_binary(encrypted_message)
    

    if len(binary_message) > 32:  
        raise ValueError("Thông điệp quá dài để giấu trong 16 điểm ảnh với 2 bit mỗi điểm!")
    
 
    img = Image.open(image_path)
    if img.mode != 'L':
        img = img.convert('L')
    pixels = img.load()
    width, height = img.size
    

    bit_index = 0
    for i in range(16):
        x = i % width
        y = i // width
        pixel = pixels[x, y]
        if bit_index + 1 < len(binary_message):
            # Lấy 2 bit từ thông điệp
            bit0 = int(binary_message[bit_index])
            bit1 = int(binary_message[bit_index + 1])
            # Xóa 2 bit thấp nhất của pixel, thêm 2 bit thông điệp
            pixel = (pixel & ~3) | (bit1 << 1) | bit0
            bit_index += 2
        pixels[x, y] = pixel
    
    # Lưu ảnh chứa tin
    img.save(output_path)
    print(f"User1: Đã giấu thông điệp vào {output_path}")

if __name__ == "__main__":
    input_image = "input.png"
    message_file = "encrypted_message.txt"
    stego_image = "stego.png"
    
    if not os.path.exists(input_image):
        print(f"Không tìm thấy {input_image}")
        exit(1)
    if not os.path.exists(message_file):
        print(f"Không tìm thấy {message_file}")
        exit(1)
    
    try:
        hide_message(input_image, message_file, stego_image)
    except Exception as e:
        print(f"Lỗi: {e}")
